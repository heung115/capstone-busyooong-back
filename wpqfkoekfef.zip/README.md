# capstone-busyooong-back

## 파이썬 가상환경

python version : 3.11.8

```bash
pip install -r requirements.txt
```

## env

api키와 같은 정보를 저장한 env파일을 노션에 공유하였습니다.
확인후 실행해주세요.
